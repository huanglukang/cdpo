

//Coordinate Descent algorithm

#include <RcppArmadillo.h>

using namespace Rcpp;
using namespace arma;
//[[Rcpp::depends(RcppArmadillo)]]
//' Compute the parameter beta in the lasso expression with Coordinate Descent algorithm
//'
//' @param X the observation matrix
//' @param Y the response variable
//' @param lambda the penalty parameter
//' @param n the number of data
//' @param p the dimension of beta
//' @return the parameter beta, functionvalue
//' @example
//' beta =cdLasso(Y,X,lambda)
// [[Rcpp::export]]
Rcpp::List cdLasso(const arma::vec& y,const arma::mat& X, const double lambda);
double softshre(const double lamb, const double z);
double lassovalue(const arma::mat& X,const arma::vec beta, const double lam,const arma::vec y); 


double softshre(const double lamb, const double z){
  double S;
  if(z>lamb){
    S=z-lamb;
  }
  else if(z<-lamb){
    S=z+lamb;
    
  }
  else{
    S=0;
  }
  return S;
  
}

double lassovalue(const arma::mat& X,const arma::vec beta, const double lam,const arma::vec y){
  int N=X.n_rows;
  double min;
  
  min=dot((y-X*beta),(y-X*beta))/N+lam*sum(abs(beta));
  return min;
  
}


Rcpp::List cdLasso(const arma::vec& y,const arma::mat& X, const double lambda) {
  int N=X.n_rows;
  int p=X.n_cols;
  arma::vec betahat(p);
  betahat.zeros();
  arma::vec betahat1(p);
  arma::vec r(N);
  arma::vec b;
  //b.ones(N);
  // arma::vec y=y0-mean(y0)*b;
  // arma::mat X=standard(X0);
  r=y-X*betahat;
  int count;
  double value;
  arma::vec values(5001);
  for(count=1; count<=5000; count = count+1){
    
    
    
    for(int j = 1; j <= p; j = j + 1){
      betahat1(j-1)=softshre(lambda,dot(r,X.col(j-1))/N+betahat(j-1));
      r=r+X.col(j-1)*(betahat(j-1)-betahat1(j-1));
    }
    betahat=betahat1;
    value=lassovalue(X,betahat,lambda,y);
    values(count)=value;
  }
  
  
  return List::create(Named("beta") = betahat,
                      Named("ncol")       = p,
                      Named("Functionvalue")=values);
}





