
//Proximal Gradient Methods Algorithm

#include <RcppArmadillo.h>

using namespace Rcpp;
using namespace arma;
//[[Rcpp::depends(RcppArmadillo)]]

//' Compute the parameter beta in the lasso expression with Proximal Operator algorithm
//'
//' @param X the observation matrix
//' @param Y the response variable
//' @param lambda the penalty parameter
//' @param n the number of data
//' @param p the dimension of beta
//' @return the parameter beta, functionvalue
//' @example
//' beta = poLasso(Y,X,lambda)
// [[Rcpp::export]]
Rcpp::List poLasso(const arma::vec& y0,const arma::mat& X0, const double lambda);
double softshre1(const double lamb, const double z);
double lassovalue1(const arma::mat& X,const arma::vec beta, const double lam,const arma::vec y);

double lassovalue1(const arma::mat& X,const arma::vec beta, const double lam,const arma::vec y){
  
  double min;
  int N=X.n_rows;
  min=dot((y-X*beta),(y-X*beta))/N+lam*sum(abs(beta));
  return min;
  
}

double softshre1(const double lamb, const double z){
  double S;
  if(z>lamb){
    S=z-lamb;
  }
  else if(z<-lamb){
    S=z+lamb;
    
  }
  else{
    S=0;
  }
  return S;
  
}



Rcpp::List poLasso(const arma::vec& y, const arma::mat& X, const double lambda){
  int N=y.n_elem;	
  int p=X.n_cols;
  // arma::mat U,V;
  // arma::colvec S;
  // arma::vec d;
  // d.ones(N);
  // arma::vec y=y0-mean(y0)*d;
  // arma::mat X=standard(X0);
  arma::mat eigvec;
  arma::vec eigval;
  double value;
  arma::vec values(5001);
  eig_sym(eigval,eigvec,(X.t()*X));
  //arma::vec b(p);
  // b.ones();
  //svd(U,S,V,X.t()*X);
  double M;
  //  M=max((S*b))/N;
  M=eigval(p-1)/N;
  int count;
  arma::vec betahat(p);
  betahat.zeros();
  arma::vec betahat1(p);
  arma::vec r(N);
  r=y-X*betahat;
  
  for(count=1;count<=5000;count=count+1){
    for(int j = 1; j < p+1; j = j + 1){
      betahat1(j-1)=softshre1((lambda/M),betahat(j-1)+(1/(N*M))*dot(X.col(j-1),r));
      
    }
    r=y-X*betahat1;
    betahat=betahat1;
    value=lassovalue1(X,betahat,lambda,y);
    values(count)=value;
  }
  return List::create(Named("beta") = betahat,
                      Named("ncol")       = p,
                      Named("Functionvalue")=values);
  
  
  
}
